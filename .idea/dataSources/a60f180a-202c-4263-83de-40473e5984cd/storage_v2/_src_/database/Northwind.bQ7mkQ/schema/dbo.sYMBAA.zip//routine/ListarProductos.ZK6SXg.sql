CREATE PROCEDURE ListarProductos
AS
SELECT * FROM Products
go

