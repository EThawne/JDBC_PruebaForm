CREATE PROCEDURE EliminarCate
	@codigo INT 

AS 

DELETE FROM Categories
WHERE CategoryID = @codigo 

