CREATE PROCEDURE Insertar_Empleados
	@Nombre 	VARCHAR(30),
	@Apellido	VARCHAR(40),
	@Fecha	DATETIME,
	@Sexo	CHAR(1),
	@Nivel	CHAR(1)
AS

DECLARE @Codigo CHAR (9)	
DECLARE @CantidadEmp int

SELECT @CantidadEmp = MAX (@CantidadEmp) + 1 
FROM Empleados

IF @CantidadEmp <= 9 
	SET @Codigo = LTRIM (STR (YEAR (@Fecha))) + @Sexo + @Nivel + '00' + LTRIM (STR(@CantidadEmp))
ELSE IF @CantidadEmp <= 99 
	SET @Codigo = LTRIM (STR (YEAR (@Fecha))) + @Sexo + @Nivel + '0' + LTRIM (STR(@CantidadEmp))
ELSE
	SET @Codigo = LTRIM (STR (YEAR (@Fecha))) + @Sexo + @Nivel + LTRIM (STR(@CantidadEmp))

INSERT INTO Empleados
(
	CodEmple, NomEmple, ApeEmple, FecNacEmple, SexEmple, NivelEmple
)
VALUES 
(@Codigo, @Nombre, @Apellido, @Fecha, @Sexo, @Nivel)

SELECT * FROM Empleados
go

