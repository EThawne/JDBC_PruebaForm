CREATE PROCEDURE InsertarCate
	@nombreCate VARCHAR (MAX),
	@descr VARCHAR (MAX)
AS

INSERT INTO Categories (CategoryName, Description)
VALUES (@nombreCate,  @descr)
go

