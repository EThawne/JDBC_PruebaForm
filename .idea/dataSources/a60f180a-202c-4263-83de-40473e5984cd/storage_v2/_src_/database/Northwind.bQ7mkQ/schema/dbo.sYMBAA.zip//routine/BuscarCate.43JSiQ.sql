CREATE PROCEDURE BuscarCate
@nombre VARCHAR (MAX)

AS

SELECT * FROM Categories
WHERE CategoryName LIKE @nombre + '%'
go

