CREATE PROCEDURE ModificarCate 
	@codigo INT,
	@nombre VARCHAR (MAX),
	@descr VARCHAR (MAX)

AS 

UPDATE Categories
SET CategoryName = @codigo, Description = @descr
WHERE CategoryID = @codigo

